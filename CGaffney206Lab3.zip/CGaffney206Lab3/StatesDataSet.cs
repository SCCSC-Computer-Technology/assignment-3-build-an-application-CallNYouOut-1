﻿namespace CGaffney206Lab3
{


    partial class StatesDataSet
    {
        partial class StatesDataTable
        {
        }
    }
}
